/**
 * This package contains classes for the CS 2110 Collision Detector
 */
